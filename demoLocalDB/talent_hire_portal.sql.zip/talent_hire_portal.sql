-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2022 at 06:27 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talent_hire_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_09_04_150453_add_cv_link_field_to_users_table', 2),
(8, '2022_09_09_112051_create_quizzes_table', 3),
(11, '2022_09_11_083555_create_quiz_tests_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`options`)),
  `options_type` enum('radio','checkbox') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'radio',
  `correct_option` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mark` tinyint(4) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 for active 0 for inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `question`, `options`, `options_type`, `correct_option`, `mark`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Question - 1', '{\"1\":\"Option - 1\",\"2\":\"Option -2\",\"3\":\"Option -3\",\"4\":\"Option- 4\"}', 'checkbox', '1,3', 5, 1, 1, '2022-09-09 08:14:16', '2022-09-11 12:58:19'),
(2, 'Question 2', '{\"1\":\"Option 1\",\"2\":\"Option 2\",\"3\":\"Option 3\",\"4\":\"Option 4\"}', 'radio', '3', 2, 1, 0, '2022-09-09 08:17:09', '2022-09-09 08:17:09'),
(3, 'Question 3', '{\"1\":\"Option 1\",\"2\":\"Option 2\",\"3\":\"Option 3\",\"4\":\"Option 4\"}', 'radio', '4', 5, 1, 0, '2022-09-09 11:12:08', '2022-09-09 11:12:08'),
(4, 'How to create a controller in laravel by cmd?', '{\"1\":\"php artisan make: generate controller contoller_name\",\"2\":\"php artisan make:controller generate\",\"3\":\"php artisan make:controller --plain\",\"4\":\"php artisan make:request controller_name create\"}', 'radio', '3', 2, 1, 1, '2022-09-11 10:52:39', '2022-09-11 10:52:39'),
(5, 'Where do we need to set database connection in Laravel?', '{\"1\":\"config.php\",\"2\":\"setting.php\",\"3\":\"In seed files\",\"4\":\".ENV file\"}', 'radio', '4', 2, 1, 1, '2022-09-11 10:53:56', '2022-09-11 10:53:56'),
(6, 'Which directory contain “robot.txt” file ?', '{\"1\":\"app\",\"2\":\"public\",\"3\":\"config\",\"4\":\"storage\"}', 'radio', '2', 2, 1, 1, '2022-09-11 10:55:21', '2022-09-11 10:55:21'),
(7, 'For what do the .env is used?', '{\"1\":\"For setting environment variables\",\"2\":\"For running cron jobs\",\"3\":\"For tracking vendors\",\"4\":\"None of These\"}', 'radio', '1', 2, 1, 1, '2022-09-11 10:56:44', '2022-09-11 10:56:44'),
(8, 'Which class is used in Laravel to handle exceptions?', '{\"1\":\"App\\\\Exceptions\\\\Handler\",\"2\":\"App\\\\Exception\\\\Handler\",\"3\":\"App\\\\Exceptions\\\\Handle\",\"4\":\"App\\\\Exceptions\\\\Handler\"}', 'checkbox', '1,4', 5, 1, 1, '2022-09-11 11:09:16', '2022-09-11 11:09:16'),
(9, 'What do you mean by dd() function?', '{\"1\":\"The full form of dd is Date and Day.\",\"2\":\"The full form of dd is Dump and Die.\",\"3\":\"The full form of dd is Diel and Deal.\",\"4\":\"The full form of dd is Dump and Die.\"}', 'checkbox', '2,4', 5, 1, 1, '2022-09-11 11:12:29', '2022-09-11 11:12:29'),
(10, 'How to get current route name?', '{\"1\":\"request()->route->getName()\",\"2\":\"request()->getName()\",\"3\":\"request()->route()->getName()\",\"4\":\"request()->route()->getName()\"}', 'checkbox', '3,4', 5, 1, 1, '2022-09-11 11:16:11', '2022-09-11 11:16:11'),
(11, 'What does ORM stands for in laravel?', '{\"1\":\"Object-Rotational Mechanisim\",\"2\":\"Overloaded-relational Mapping\",\"3\":\"Object-relational Mapping\",\"4\":\"Object-relational Mapping\"}', 'checkbox', '3,4', 5, 1, 1, '2022-09-11 11:18:21', '2022-09-11 11:18:21');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_tests`
--

CREATE TABLE `quiz_tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quiz_test_details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_questions` tinyint(4) DEFAULT NULL,
  `quiz_perform_qty` tinyint(4) DEFAULT NULL,
  `quiz_pass_qty` tinyint(4) DEFAULT NULL,
  `total_marks_aquired` double(8,2) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `time_consumed` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checked_by` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Checked by admin (examiner)',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_tests`
--

INSERT INTO `quiz_tests` (`id`, `quiz_test_details`, `total_questions`, `quiz_perform_qty`, `quiz_pass_qty`, `total_marks_aquired`, `user_id`, `time_consumed`, `checked_by`, `created_at`, `updated_at`) VALUES
(1, '[\"10: 2,3\",\"11: 3,2\",\"8: 3,2,3,2,3,4\",\"4: 3\",\"1: 3,2,3,2\",\"5: 3\",\"2: 3\",\"6: 2\",\"9: 3,2,3,2,3,4,3,2\",\"3: 2\"]', 10, 10, 3, 6.00, 2, '0:0:31', NULL, '2022-09-11 13:08:37', '2022-09-11 13:08:37'),
(4, '[\"10: 2,4,3,4\",\"4: 3\",\"5: 4\",\"1: 2,4,3,4,3,4,3\",\"8: 2,4,3,4,3,4\",\"2: 3\",\"6: 2\",\"9: 2,4\",\"11: 2,4,3,4,3,4,3,3,4\"]', 10, 9, 5, 13.00, 5, '0:01:20', NULL, '2022-09-12 00:29:18', '2022-09-12 00:29:18'),
(5, '[\"10: 4\",\"4: 3\",\"1: 3\",\"8: 4\",\"9: 4\",\"6: 2\",\"7: 1\",\"5: 4\",\"11: 3,4\"]', 9, 9, 9, 33.00, 11, '00:01:05', NULL, '2022-09-12 10:20:27', '2022-09-12 10:20:27'),
(6, '[\"10: 3\",\"4: 3\",\"5: 4\",\"1: 2\",\"8: 1\",\"6: 2\",\"7: 1\",\"9: 2\",\"11: 3,4\"]', 9, 9, 8, 28.00, 3, '00:00:58', NULL, '2022-09-12 10:26:37', '2022-09-12 10:26:37');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cv_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_as` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 for user, 1 for admin',
  `status` enum('pending','approved','rejected','qualified') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `cv_link`, `role_as`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@analyzen.com', NULL, NULL, 1, 'approved', NULL, '$2y$10$mr59mxEQXbhe8CpAWlq9uedRyng/CRkjFgoXn1CIdak7B46yhlH.y', NULL, '2022-09-03 13:11:47', '2022-09-03 13:11:47'),
(2, 'Tanvirul Haque', 'tanvirhaque9051@gmail.com', '+8801715-450677', 'GPr3Eqic5WwOZsmvfS9BpLOHj20IXRUgJnTOY31P.pdf', 0, 'approved', NULL, '$2y$10$EUSeBUtMoS9/bqtEiidk8OH9Ui9IRVondQ0F2w.CSehgAbTW6K1K.', NULL, '2022-09-03 14:17:48', '2022-09-11 11:38:03'),
(3, 'Aynal Haque', 'aynal@gmail.com', '+8801763-825660', '5bEQ8t5OE4qMxLgEDZrBWDNhT9GwV2vZ7QcmSgtx.pdf', 0, 'approved', NULL, '$2y$10$AilTBh3Twu.D8pd6ym89jesT1dab67UHArfqxbfDlCf.2d45AvwM6', NULL, '2022-09-04 08:54:56', '2022-09-11 11:38:36'),
(4, 'Robiul Islam', 'robiul@gmail.com', '+8801763-825331', 'I5ITbOO9bH9hjq432IC9RtQEp1aYEyu4UyILeGzp.pdf', 0, 'approved', NULL, '$2y$10$QPHTCN3ZDcPCHwLLsVnyn.fr7dJjO3TCAboL0W.6ILQFpIQ7xFWQu', NULL, '2022-09-04 08:56:24', '2022-09-11 11:38:56'),
(5, 'Khalid Ahmed', 'khalids@gmail.com', '+8801715-450672', 'vhHXFgAAwgvV2FHbIED3yOZhENr2m95vhHqmnW2b.pdf', 0, 'qualified', NULL, '$2y$10$WWxXZqraRy4RtMPiY8.CUO8Du1ZLP0HfccaSxR/2EXoruJphte3Qy', NULL, '2022-09-04 09:39:48', '2022-09-12 04:57:30'),
(6, 'Rashedul bari', 'rashed@gmail.com', '+8801715-450679', NULL, 0, 'pending', NULL, '$2y$10$bcu1mq9CM0GSL48ef1qeauKDuf6m1H5s4iyQl3sG8sujZLPWmyHK6', NULL, '2022-09-08 22:58:09', '2022-09-08 22:58:09'),
(8, 'Kamal Hossen', 'kamal@gmail.com', '+8801715-450625', NULL, 0, 'pending', NULL, '$2y$10$Z8tgnBsvzXWt04XaPGqg2O.hmcIiJpO7QiFEFg1Q6cUjqdN/U.x1m', NULL, '2022-09-08 23:05:29', '2022-09-08 23:05:29'),
(9, 'Kabir Mohammad', 'kabir2@gmail.com', '+8801715-451678', 'XMhY4kNFWeHeidpBmfZd0fbD4ac2NCFKCjwMm4Pi.pdf', 0, 'pending', NULL, '$2y$10$KhsGIsalHHL3r38Dn/RDG.4udelaOXFBOOOvStu7SXj6.DYXEIMXi', NULL, '2022-09-08 23:10:32', '2022-09-12 05:08:27'),
(10, 'Mizan Mahmud', 'mizan@gmail.com', '+8801715-450671', 'NWvAd4m0hBZY5cqoc4M33M9Xy2fZr2pjxubsmOP8.pdf', 0, 'approved', NULL, '$2y$10$BIR7Wo/a8DpYAOW.mu95.u36k//cZyCdaufgxO.FcLucRvyjgyRg6', NULL, '2022-09-08 23:12:58', '2022-09-12 05:08:05'),
(11, 'Habibullah Sadi', 'sadi@gmail.com', '+8801715-420678', NULL, 0, 'approved', NULL, '$2y$10$FPuoX4xS9JFRV5YKGf3TPOiUYtcjA.ndQ21seXuf8Zxwu3TKQRLyC', NULL, '2022-09-08 23:14:47', '2022-09-12 05:11:54'),
(12, 'Mohammadullah Rafi', 'rafi@gmail.com', '+8801715-452678', 'PKtnDUx6Uf1bfAa8v6yFI6EVVQ7IVagxTzUZelGw.pdf', 0, 'approved', NULL, '$2y$10$zxp4JH//vGOPUdGsaWyDXu/BGJN.Xjj3Mu8QnzxdQSECjrl0ceuPi', NULL, '2022-09-08 23:26:50', '2022-09-11 11:39:47'),
(14, 'Sadekur Rahman', 'sadek@gmail.com', '+8801715-450687', NULL, 0, 'pending', NULL, '$2y$10$gtLY1peF2hp2A1q0Iv2fwuKCEuee56zwH7P.xnavtBbcOwLPdjaii', NULL, '2022-09-11 10:21:47', '2022-09-11 10:21:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_tests`
--
ALTER TABLE `quiz_tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `quiz_tests`
--
ALTER TABLE `quiz_tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
